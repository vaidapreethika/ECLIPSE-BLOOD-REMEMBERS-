ECLIPSE — Blood Remembers V3

This version changes the game into a top-down cartoon survival/combat adventure inspired by the feel of mobile battle/survival games, while keeping the story and world original.

NEW:
- Physical paper LETTER clues are clearly visible in the world.
- Every letter has a floating "LETTER" label and glowing marker.
- Walk close and press E to pick it up.
- Each letter opens as a readable parchment and changes the story.
- Vampires, witches and shadow hunters chase the player.
- Enemies have health bars and attack the player.
- Player can attack with LEFT CLICK (or SPACE).
- Different enemy types.
- Four levels, with different letters and story revelations.
- Large haunted town with many buildings and dead trees.
- Detailed cartoon-style character drawing directly on the canvas.
- Health and game-over/restart system.
- Map shows letters, enemies, NPCs and player.
- Journal records recovered letters.
- Atmospheric procedural background music.

CONTROLS:
WASD / Arrow Keys = Move
SHIFT = Run
LEFT CLICK = Attack
SPACE = Attack
E = Pick up a nearby letter
M = Map
J = Journal

RUN:
1. Extract the ZIP.
2. Open ECLIPSE_Blood_Remembers_V3 in VS Code.
3. Open index.html with Live Server.
4. Choose Mara or Elias.

No external libraries, backend or image/audio assets are required.
