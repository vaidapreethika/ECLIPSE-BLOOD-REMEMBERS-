const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const mapCanvas=document.getElementById("mapCanvas"),mctx=mapCanvas.getContext("2d");
const W=canvas.width,H=canvas.height,WW=3600,WH=2500;
let mode="menu",character="Mara",level=1,health=100,cam={x:0,y:0},letters=[],enemies=[],npcs=[],buildings=[],trees=[],roads=[],bullets=[],particles=[],keys={},mouse={x:550,y:325,down:false};
let player={x:1800,y:1250,r:18,speed:2.65,damage:1,attackCd:0,inv:0,angle:0};
const stories=[
 {name:"THE LETTER ON THE ROAD",letters:[
  ["The First Letter", "If you are reading this, you have already forgotten me. Start at the house with the dead trees. Do not trust the first person who calls your name.", 780,430],
  ["The Second Letter", "The town is watching. The shadows are not animals. They are hungry pieces of the thing beneath Black Hollow. Find the silver mark before midnight.", 1320,650],
  ["The Third Letter", "You came here willingly. A witch erased your memory. A vampire carried you home. The humans built the town around the secret.", 2220,520]
 ],story:"The letters prove that your memory loss was deliberate. Someone erased the night you first entered Black Hollow."},
 {name:"THE WITCH'S OATH",letters:[
  ["The Witch's Letter", "I sealed the memory because you begged me to. Your blood was the key. If the seal breaks, the thing below the church wakes.", 1850,470],
  ["The Burnt Letter", "The vampires are not hunting you. They are guarding the old pact. Find the manor and look beneath the portrait.", 2840,720],
  ["The Hidden Letter", "Three groups made the same promise: humans, witches and vampires. You were the fourth signature.", 1110,1520]
 ],story:"The witches erased your memory to protect an ancient pact. But someone has started breaking it."},
 {name:"THE BLOOD HUNT",letters:[
  ["The Vampire Letter", "Do not run when you see the red eyes. Ask for Adrian. He remembers the night you disappeared.", 2920,930],
  ["The Blood-Stained Letter", "Your blood can open the eclipse gate. Every hunter in town wants it. Survive until the church bell rings.", 2250,1580],
  ["The Portrait Letter", "The portrait is older than the town. Look at the face beside yours. That is who you were before the memory was erased.", 2830,1500]
 ],story:"The vampires were protecting you from hunters. The blood in your veins is connected to the eclipse gate."},
 {name:"ECLIPSE NIGHT",letters:[
  ["The Final Warning", "When the moon turns black, every door in Black Hollow will open. Take the eclipse stone to the church.", 3050,1120],
  ["The Last Letter", "You erased yourself because you were the only one who could close the gate. Remembering is the price.", 1700,1980],
  ["The Letter You Wrote", "If you remember everything, do not blame the witch or the vampire. You chose this. Finish what you started.", 650,2020]
 ],story:"Your final memories return. You chose to forget yourself so the eclipse could never be opened."}
];

function startGame(c){character=c;document.getElementById("startScreen").classList.add("hidden");document.getElementById("hud").classList.remove("hidden");level=1;startLevel();startAudio();notice("BLACK HOLLOW","Find the letters. They are physical paper scattered around the town. Hunters are guarding them.");}
function startLevel(){mode="play";health=100;bullets=[];particles=[];letters=[];enemies=[];npcs=[];buildings=[];trees=[];roads=[];player={x:1800,y:1250,r:18,speed:character==="Elias"?2.95:2.65,damage:1,attackCd:0,inv:0,angle:0};generateWorld();updateHUD();drawMap();}
function generateWorld(){
 roads=[
  {x:0,y:1120,w:3600,h:170},{x:1710,y:0,w:170,h:2500},{x:450,y:480,w:120,h:1750},
  {x:3000,y:300,w:130,h:1900},{x:560,y:570,w:2450,h:110},{x:420,y:1850,w:2850,h:115}
 ];
 const specs=[
 [610,280,290,190,"DEAD TREE FARMHOUSE"],[1090,300,270,180,"BLACK HOLLOW INN"],[1800,250,300,210,"WITCH HOUSE"],
 [2260,330,310,190,"OLD LIBRARY"],[2790,510,370,250,"VAMPIRE MANOR"],[650,720,280,190,"HOSPITAL"],
 [1090,760,260,180,"POLICE STATION"],[1800,760,300,190,"RITUAL HOUSE"],[2290,770,270,180,"ABANDONED SHOP"],
 [2820,900,280,190,"OLD CHURCH"],[610,1400,300,190,"MOTEL"],[1080,1450,300,190,"TRAIN DEPOT"],
 [1790,1400,330,210,"THEATER"],[2350,1380,330,210,"OLD SCHOOL"],[2850,1450,290,180,"FUNERAL HOME"],
 [480,1900,310,180,"MILL"],[1010,1920,310,180,"COVEN COTTAGE"],[1640,1900,350,210,"CITY HALL"],
 [2230,1900,290,180,"CLOCK TOWER"],[2730,1930,390,210,"ABANDONED MANSION"]];
 buildings=specs.map((a,i)=>({x:a[0],y:a[1],w:a[2],h:a[3],name:a[4],id:i}));
 for(let i=0;i<150;i++){let a=Math.sin(i*88+level*33)*43758.5,b=Math.sin(i*41+level*17)*12345.6,x=80+(a-Math.floor(a))*3440,y=80+(b-Math.floor(b))*2340;if(!nearRoad(x,y,80))trees.push({x,y,s:18+(i%24)});}
 const s=stories[level-1];s.letters.forEach((l,i)=>letters.push({x:l[2],y:l[3],title:l[0],text:l[1],found:false,id:i}));
 npcs=[
  {x:1880,y:540,name:"SELENE",type:"witch",text:"You are looking for letters. I am not the one who wrote them. But I know why they exist."},
  {x:3010,y:820,name:"ADRIAN",type:"vampire",text:"If the hunters see you with a letter, they will chase you until dawn. Keep moving."},
  {x:940,y:1100,name:"NOAH",type:"human",text:"I saw a red-eyed creature near the church. It was guarding something."}
 ];
 // Hunters spawn around each letter and a few roamers.
 letters.forEach((l,i)=>{for(let j=0;j<2;j++)enemies.push(makeEnemy(l.x+(j?80:-80),l.y+(j?70:-65),i));});
 for(let i=0;i<8;i++)enemies.push(makeEnemy(350+(i*397)%3000,350+(i*281)%2050,10+i));
}
function makeEnemy(x,y,seed){return{x,y,r:19,s:.65+(level*.08)+(seed%3)*.12,hp:2+Math.floor(level/2),max:2+Math.floor(level/2),hitCd:0,type:seed%3===0?"vampireHunter":seed%3===1?"shadow":"witchHunter",wander:seed};}
function nearRoad(x,y,d){return roads.some(r=>x>r.x-d&&x<r.x+r.w+d&&y>r.y-d&&y<r.y+r.h+d)}
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==="e")interact();if(e.key.toLowerCase()==="m")toggleMap();if(e.key.toLowerCase()==="j")toggleJournal();if(e.key===" "){e.preventDefault();attack();}});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
canvas.addEventListener("mousemove",e=>{let r=canvas.getBoundingClientRect();mouse.x=(e.clientX-r.left)*W/r.width;mouse.y=(e.clientY-r.top)*H/r.height;});
canvas.addEventListener("mousedown",e=>{mouse.down=true;attack();});canvas.addEventListener("mouseup",()=>mouse.down=false);

function update(){
 if(mode!=="play")return;
 let dx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),dy=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0),len=Math.hypot(dx,dy)||1;
 let sp=player.speed*(keys.shift?1.6:1);if(dx||dy){player.x+=dx/len*sp;player.y+=dy/len*sp;player.angle=Math.atan2(dy,dx);}
 player.x=Math.max(40,Math.min(WW-40,player.x));player.y=Math.max(40,Math.min(WH-40,player.y));
 player.attackCd=Math.max(0,player.attackCd-1);player.inv=Math.max(0,player.inv-1);
 if(mouse.down)attack();
 enemies.forEach(e=>updateEnemy(e));
 bullets.forEach(b=>{b.x+=b.vx;b.y+=b.vy;b.life--;});
 bullets=bullets.filter(b=>b.life>0&&!bulletHitWall(b));
 bullets.forEach(b=>enemies.forEach(e=>{if(Math.hypot(b.x-e.x,b.y-e.y)<e.r+5){e.hp-=1;b.life=0;burst(e.x,e.y,"hit");}}));
 enemies=enemies.filter(e=>{if(e.hp<=0){burst(e.x,e.y,"death");return false}return true});
 particles.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.life--;q.vy+=.01});
 particles=particles.filter(q=>q.life>0);
 cam.x+=(Math.max(0,Math.min(WW-W,player.x-W/2))-cam.x)*.12;cam.y+=(Math.max(0,Math.min(WH-H,player.y-H/2))-cam.y)*.12;
 updatePrompt();updateHUD();
}
function updateEnemy(e){
 let dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy);
 if(d<560){e.x+=dx/d*e.s;e.y+=dy/d*e.s;}
 else {e.x+=Math.sin((Date.now()/900)+e.wander)*.25;e.y+=Math.cos((Date.now()/1100)+e.wander)*.25;}
 e.hitCd=Math.max(0,e.hitCd-1);
 if(d<42&&e.hitCd===0&&player.inv===0){health-=e.type==="vampireHunter"?9:6;e.hitCd=42;player.inv=22;burst(player.x,player.y,"damage");if(health<=0)gameOver();}
}
function attack(){
 if(mode!=="play"||player.attackCd>0)return;
 player.attackCd=14;let ang=Math.atan2(mouse.y-H/2,mouse.x-W/2),speed=9;
 bullets.push({x:player.x+Math.cos(ang)*25,y:player.y+Math.sin(ang)*25,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,life:55});
 burst(player.x+Math.cos(ang)*22,player.y+Math.sin(ang)*22,"shot");
}
function bulletHitWall(b){return b.x<0||b.x>WW||b.y<0||b.y>WH}
function burst(x,y,type){let col=type==="damage"?"#d65b70":type==="death"?"#8e6da0":type==="shot"?"#d9c38b":"#c8a5d8";for(let i=0;i<8;i++){let a=Math.random()*Math.PI*2,s=.5+Math.random()*2;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:18+Math.random()*15,col});}}
function draw(){
 ctx.clearRect(0,0,W,H);ctx.save();ctx.translate(-cam.x,-cam.y);drawWorld();drawBuildings();drawLetters();drawNPCs();drawEnemies();drawBullets();drawParticles();drawPlayer();drawDarkness();ctx.restore();
}
function drawWorld(){
 ctx.fillStyle="#171817";ctx.fillRect(0,0,WW,WH);
 // large gloomy rural landscape
 ctx.fillStyle="#242421";ctx.fillRect(0,0,WW,WH);
 roads.forEach(r=>{ctx.fillStyle="#373331";ctx.fillRect(r.x,r.y,r.w,r.h);ctx.strokeStyle="#504944";ctx.lineWidth=3;ctx.strokeRect(r.x,r.y,r.w,r.h)});
 ctx.fillStyle="#151614";ctx.fillRect(0,0,WW,260);
 trees.forEach(t=>{ctx.strokeStyle="#0b0d0c";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(t.x,t.y+35);ctx.lineTo(t.x,t.y-55);ctx.stroke();for(let k=0;k<5;k++){ctx.beginPath();ctx.moveTo(t.x,t.y-30);ctx.lineTo(t.x+(k-2)*t.s*1.4,t.y-72-k*12);ctx.stroke()}ctx.fillStyle="#0e100f";ctx.beginPath();ctx.arc(t.x,t.y-65,t.s*.45,0,Math.PI*2);ctx.fill();});
}
function drawBuildings(){
 buildings.forEach(b=>{ctx.fillStyle="#090a0b";ctx.fillRect(b.x+10,b.y+13,b.w,b.h);ctx.fillStyle="#56504a";ctx.fillRect(b.x,b.y,b.w,b.h*.68);ctx.fillStyle="#302d2b";ctx.beginPath();ctx.moveTo(b.x-15,b.y);ctx.lineTo(b.x+b.w/2,b.y-b.h*.34);ctx.lineTo(b.x+b.w+15,b.y);ctx.closePath();ctx.fill();
 ctx.fillStyle="#181717";for(let x=b.x+28;x<b.x+b.w-15;x+=52){ctx.fillRect(x,b.y+42,24,31);ctx.fillRect(x,b.y+103,24,31);}ctx.fillStyle="#161515";ctx.fillRect(b.x+b.w/2-23,b.y+b.h*.47,46,b.h*.21);
 ctx.fillStyle="#c3b6ad";ctx.font="11px Georgia";ctx.textAlign="center";ctx.fillText(b.name,b.x+b.w/2,b.y+b.h+20);});
}
function drawLetters(){
 letters.forEach(l=>{if(l.found)return;let pulse=3+Math.sin(Date.now()/180)*2;
 ctx.shadowBlur=24;ctx.shadowColor="#e5c77e";ctx.fillStyle="#d9c69d";ctx.fillRect(l.x-13,l.y-10,26,20);ctx.shadowBlur=0;
 ctx.strokeStyle="#6e5840";ctx.strokeRect(l.x-13,l.y-10,26,20);ctx.fillStyle="#8e7050";ctx.fillRect(l.x-8,l.y-5,16,2);ctx.fillRect(l.x-8,l.y,12,2);
 ctx.fillStyle="#f1d58c";ctx.beginPath();ctx.arc(l.x,l.y-25,pulse,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#e8d6ad";ctx.font="bold 11px Arial";ctx.textAlign="center";ctx.fillText("LETTER",l.x,l.y-36);});
}
function drawNPCs(){npcs.forEach(n=>{drawCharacter(n.x,n.y,n.type==="witch"?"#79519a":"#704050",n.type);ctx.fillStyle="#eee";ctx.font="12px Georgia";ctx.textAlign="center";ctx.fillText(n.name,n.x,n.y-40);});}
function drawEnemies(){
 enemies.forEach(e=>{let c=e.type==="vampireHunter"?"#8e394d":e.type==="witchHunter"?"#6b4c8e":"#19151f";drawCharacter(e.x,e.y,c,e.type);
 // health bar
 ctx.fillStyle="#120c10";ctx.fillRect(e.x-20,e.y-39,40,5);ctx.fillStyle="#c74c62";ctx.fillRect(e.x-20,e.y-39,40*(e.hp/e.max),5);
 if(Math.hypot(player.x-e.x,player.y-e.y)<260){ctx.fillStyle="#df8b99";ctx.font="9px Arial";ctx.textAlign="center";ctx.fillText("HUNTING",e.x,e.y-46);}
 });
}
function drawCharacter(x,y,c,type){
 ctx.fillStyle="#0009";ctx.beginPath();ctx.ellipse(x,y+24,22,8,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#17141a";ctx.fillRect(x-12,y+7,24,21);ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x-15,y+27);ctx.lineTo(x-10,y-1);ctx.lineTo(x+10,y-1);ctx.lineTo(x+15,y+27);ctx.closePath();ctx.fill();
 ctx.fillStyle="#d8b8aa";ctx.beginPath();ctx.arc(x,y-13,12,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#17131b";ctx.beginPath();ctx.arc(x,y-17,13,Math.PI,Math.PI*2);ctx.fill();
 ctx.fillStyle="#f2e8e0";ctx.beginPath();ctx.arc(x-5,y-13,2,0,Math.PI*2);ctx.arc(x+5,y-13,2,0,Math.PI*2);ctx.fill();
 if(type.includes("vampire")||type==="vampire"){ctx.fillStyle="#d9475d";ctx.fillRect(x-7,y-14,4,2);ctx.fillRect(x+3,y-14,4,2);ctx.fillStyle="#eee";ctx.beginPath();ctx.moveTo(x-5,y-1);ctx.lineTo(x-3,y+4);ctx.lineTo(x,y-1);ctx.lineTo(x+3,y+4);ctx.lineTo(x+5,y-1);ctx.fill();}
 if(type.includes("witch")||type==="witch"){ctx.fillStyle="#201326";ctx.beginPath();ctx.moveTo(x-18,y-23);ctx.lineTo(x,y-50);ctx.lineTo(x+18,y-23);ctx.closePath();ctx.fill();}
}
function drawBullets(){bullets.forEach(b=>{ctx.shadowBlur=14;ctx.shadowColor="#e8c77c";ctx.fillStyle="#ead18e";ctx.beginPath();ctx.arc(b.x,b.y,5,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;});}
function drawParticles(){particles.forEach(q=>{ctx.fillStyle=q.col;ctx.globalAlpha=Math.max(0,q.life/30);ctx.fillRect(q.x,q.y,3,3);ctx.globalAlpha=1;});}
function drawPlayer(){if(player.inv%4<2)return;let ang=Math.atan2(mouse.y-H/2,mouse.x-W/2);drawCharacter(player.x,player.y,character==="Mara"?"#80509a":"#4c688c",character==="Mara"?"witch":"vampire");ctx.strokeStyle="#e1ca92";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(player.x,player.y+7);ctx.lineTo(player.x+Math.cos(ang)*28,player.y+Math.sin(ang)*28);ctx.stroke();}
function drawDarkness(){
 let g=ctx.createRadialGradient(player.x,player.y,120,player.x,player.y,560);g.addColorStop(0,"#0000");g.addColorStop(.55,"#04050a35");g.addColorStop(1,"#020307e8");ctx.fillStyle=g;ctx.fillRect(cam.x,cam.y,W,H);
}
function updatePrompt(){
 let nearest=null,nd=62;letters.forEach(l=>{if(!l.found){let d=Math.hypot(player.x-l.x,player.y-l.y);if(d<nd){nearest=l;nd=d}}});
 const pr=document.getElementById("letterPrompt");pr.classList.toggle("hidden",!nearest);
}
function interact(){
 let nearest=null,nd=65;letters.forEach(l=>{if(!l.found){let d=Math.hypot(player.x-l.x,player.y-l.y);if(d<nd){nearest=l;nd=d}}});
 if(!nearest){notice("NOTHING HERE","Search the roads, houses and dark corners. The letters are physical paper with a glowing marker above them.");return;}
 nearest.found=true;document.getElementById("speaker").textContent=character.toUpperCase()+" FOUND A LETTER";document.getElementById("letterTitle").textContent=nearest.title;document.getElementById("letterText").textContent=nearest.text;document.getElementById("dialogue").classList.remove("hidden");updateHUD();drawMap();
 if(letters.every(l=>l.found))setTimeout(completeLevel,500);
}
function closeDialogue(){document.getElementById("dialogue").classList.add("hidden");}
function completeLevel(){if(mode!=="play")return;mode="level";document.getElementById("levelTitle").textContent=level===4?"THE LAST MEMORY":"LEVEL "+level+" COMPLETE";document.getElementById("levelStory").textContent=stories[level-1].story;document.getElementById("levelPanel").classList.remove("hidden");}
function nextLevel(){document.getElementById("levelPanel").classList.add("hidden");if(level>=4){showEnding();return;}level++;startLevel();notice("NEW LEVEL",stories[level-1].name+" — the hunters are stronger now.");}
function showEnding(){mode="ending";document.getElementById("ending").classList.remove("hidden");document.getElementById("endingTitle").textContent=character==="Mara"?"MARA — THE WITCH WHO FORGOT":"ELIAS — THE VAMPIRE WHO REMEMBERED";document.getElementById("endingText").textContent=character==="Mara"?"The letters were written by you. You erased your memory to hide the eclipse seal. The witch protected it. The vampire guarded you. Now you remember why you chose to disappear — and the final choice is yours.":"The letters were written by you. You erased your memory because vampire blood was the key to the eclipse gate. The hunters wanted you. The witch hid you. Now the blood remembers everything.";}
function gameOver(){mode="dead";document.getElementById("gameOver").classList.remove("hidden");}
function restartLevel(){document.getElementById("gameOver").classList.add("hidden");startLevel();}
function toggleMap(){if(mode==="menu"||mode==="dead"||mode==="ending")return;document.getElementById("mapPanel").classList.toggle("hidden");drawMap();}
function toggleJournal(){if(mode==="menu"||mode==="dead"||mode==="ending")return;document.getElementById("journalPanel").classList.toggle("hidden");renderJournal();}
function renderJournal(){document.getElementById("journal").innerHTML=letters.map(l=>`<div class="jline"><b>${l.found?"✉ "+l.title:"? Unknown letter"}</b><br>${l.found?l.text:"Find the glowing paper letter and press E."}</div>`).join("");}
function drawMap(){mctx.fillStyle="#111416";mctx.fillRect(0,0,780,470);let sx=780/WW,sy=470/WH;roads.forEach(r=>{mctx.fillStyle="#3a3635";mctx.fillRect(r.x*sx,r.y*sy,r.w*sx,r.h*sy)});buildings.forEach(b=>{mctx.fillStyle="#514c50";mctx.fillRect(b.x*sx,b.y*sy,b.w*sx,b.h*sy)});letters.forEach(l=>{mctx.fillStyle=l.found?"#777":"#e0bd69";mctx.beginPath();mctx.arc(l.x*sx,l.y*sy,6,0,Math.PI*2);mctx.fill()});enemies.forEach(e=>{mctx.fillStyle="#a13e53";mctx.fillRect(e.x*sx-3,e.y*sy-3,6,6)});npcs.forEach(n=>{mctx.fillStyle=n.type==="witch"?"#9a62b2":"#9b485e";mctx.fillRect(n.x*sx-4,n.y*sy-4,8,8)});mctx.fillStyle="#fff";mctx.beginPath();mctx.arc(player.x*sx,player.y*sy,6,0,Math.PI*2);mctx.fill();}
function updateHUD(){document.getElementById("letterCount").textContent=`${letters.filter(l=>l.found).length}/${letters.length}`;document.getElementById("levelText").textContent=level;document.getElementById("levelName")&&(document.getElementById("levelName").textContent=stories[level-1].name);document.getElementById("healthBar").style.width=Math.max(0,health)+"%";document.getElementById("healthText").textContent=Math.ceil(health);document.getElementById("mission").textContent=letters.length&&letters.every(l=>l.found)?"MEMORY RESTORED":"FIND THE LETTERS";}
let audioCtx=null;
function startAudio(){try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;audioCtx=new A();let gain=audioCtx.createGain();gain.gain.value=.025;gain.connect(audioCtx.destination);let notes=[55,58.27,65.41,49,55,73.42];let i=0;setInterval(()=>{if(mode!=="play")return;let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type="sine";o.frequency.value=notes[i++%notes.length];g.gain.setValueAtTime(.001,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.08,audioCtx.currentTime+.25);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+2);o.connect(g);g.connect(gain);o.start();o.stop(audioCtx.currentTime+2.1)},850);}catch(e){}}
function notice(t,s){let n=document.getElementById("notice");n.innerHTML=`<b>${t}</b><br>${s}`;n.classList.remove("hidden");clearTimeout(window.nt);window.nt=setTimeout(()=>n.classList.add("hidden"),4300);}
function loop(){update();draw();requestAnimationFrame(loop)}loop();
